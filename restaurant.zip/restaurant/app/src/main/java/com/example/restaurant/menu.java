package com.example.restaurant;

public class menu {
    private string nama;
    private string harga;
    private string gambar;

    public menu(string datanama, string dataharga, string datagambar){
        nama = datanama;
        harga = dataharga;
        gambar = datagambar;
    }

    public string getNama() {
        return nama;
    }

    public string getHarga() {
        return harga;
    }

    public string getGambar() {
        return gambar;
    }
}
