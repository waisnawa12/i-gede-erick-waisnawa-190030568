package com.example.restaurant;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.lifecycle.GenericLifecycleObserver;

public class  menuadapter {
    public menuadpater(context context, array list<menu> menumakanan){
        private context context;
        private Arraylist<menu> menu;

        public menuadapter(context mcontext, Arraylist<menu> menumakanan){
            context= mcontext;
            menu= menumakanan;
        }
    }

    @NonNull
    @Override
    public menuviewholder onCreateViewholder(@NonNull ViewGroup parent, int view type){
        view = layoutinflater.from(context).inflater(R.layout.item_menu,parent, attach to root)

         return new menuviewholder(v);
    }
    @Override
    public void onBindViewHolder (@NonNull, int position){
        menu menubaru= menu.get(position);
        string gambarbaru = menubaru.getGambar()
        string harga = menubaru.getHarga();
        string nama = menubaru.getNama();

        holder.tvnamadata.setText(nama);
        holder.tvhargadata.setText(harga);
     Glide
             .with(context)RequestManager
            .load(gambarbaru)
            .centercroop()
            .into(holder.imdata);



    }

    @Override
    public int getitemcount(){
        return menu.size()
    }
    public class menuviewholder extends RecyclerView.ViewHolder{
        public imageview imdata;
        public textview tvhargadata;
        public textview tvnamadata;

        public menuViewHolder(@NonNull View itemView){
            super(itemView);
            imdata= itemView.findviewbyid(R.id.img_menu);
            tvhargadata= itemView.findviewbyid(R.id.tv_harga);
            tvnamadata= itemView.findviewbyid(R.id.tv_nama);





        }
    }
}
