package com.example.restaurant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.DownloadManager;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private menuadapter menuadapter;
    private recyclerview recyclerview;
    private ArrayList<menu> menu;
    int jumdata;
    private RequestQueue RequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerview=findViewById(R.id.rv_list);
        recyclerview.setHasFixedsize(true);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));

        menu =new ArrayList<>();
        RequestQueue= volley.newRequestQueue(this);
        parseJSON();
    }
}
    private void parseJSON(){
        string url= "https://jsonabdi.000webhostapp.com/koneksi.php";
        jsonArrayRequest Request = new jsonarrayrwquest(Request.Method.GET, url, null,)
                new response.Listener<JSONArray>(){
                    @Override
                    public void onResponse(JSONArray respose){
                        jumdata=response.length();
                        try{
                            for (int i=0; i<jumdata;i++){
                                JSONObject data =Response.getJSONobject(i);
                                string gambarmenu=data.getString("gambar");
                                string namamenu=data.getString("nama");
                                string hargamenu=data.getString("harga");
                                menus.add(new menu((namamenu,hargamenu,gambarmenu));
                            }
                            menuadapter = new menuadapter(MainActivity,this,menu);
                            recyclerview.setAdapter(menuadapter);
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                }new response.ErorListener(){
                @Override
                public void onErorResponse(volleyEror eror){
                    eror.printstacktrace();
                }
        }
            RequestQueue.add(request);
    }